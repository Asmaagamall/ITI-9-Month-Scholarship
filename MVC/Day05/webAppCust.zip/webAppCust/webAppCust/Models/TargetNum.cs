﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webAppCust.Models
{
    public class TargetNum : ValidationAttribute
    {
        int value;
        public TargetNum(int num) 
        {
            value = num;         
        }

        public override bool IsValid(object obj)
        {
            if(obj == null)
            {
                return false;
            }
            else
            {
                if(obj is int targetVal) 
                {
                    if(targetVal == value) {
                        return true;
                    }
                    else
                    {
                        ErrorMessage = "You should enter just" + value + "Digit";
                        return false;
                    }
                
                }
                else
                {
                    return false;
                }
            }
        }
    }
}